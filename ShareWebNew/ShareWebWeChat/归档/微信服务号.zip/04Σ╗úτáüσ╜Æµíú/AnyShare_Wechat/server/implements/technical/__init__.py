class Dummy(object):
    """ define dummy class """
    pass